from PIL import Image
import toml
import random

wrap = Image.open('wrap.png')
wrapInfo = toml.load('wrap.toml')

#서브 꽃 1 배치
flower = Image.open('hyacinth_1.png')
flowerInfo = toml.load('hyacinth_1.toml')
change = wrapInfo['ratio'] / flowerInfo['ratio']

flower = flower.resize((int(flower.width * change), int(flower.height * change)), Image.LANCZOS)

LT = wrapInfo['sub_cord_left_top']
RB = wrapInfo['sub_cord_right_down']

flower_count = random.randint(4, 6)

for i in range(flower_count):
    x = random.randint(LT[0], RB[0])
    y = random.randint(LT[1], RB[1])
    paste_location = (x - int(flower.width / 2), y - int(flower.height / 2))

    if flower.mode == 'RGBA':
        alpha = flower.split()[3]
        wrap.paste(flower, paste_location, mask=alpha)
    else:
        wrap.paste(flower, paste_location)

#서브 꽃 2 배치
flower = Image.open('purple_tulip_1.png')
flowerInfo = toml.load('purple_tulip_1.toml')
change = wrapInfo['ratio'] / flowerInfo['ratio']

flower = flower.resize((int(flower.width * change), int(flower.height * change)), Image.LANCZOS)

LT = wrapInfo['sub_cord_left_top']
RB = wrapInfo['sub_cord_right_down']

flower_count = random.randint(4, 6)
for i in range(flower_count):
    x = random.randint(LT[0], RB[0])
    y = random.randint(LT[1], RB[1])
    paste_location = (x - int(flower.width / 2), y - int(flower.height / 2))

    if flower.mode == 'RGBA':
        alpha = flower.split()[3]
        wrap.paste(flower, paste_location, mask=alpha)
    else:
        wrap.paste(flower, paste_location)

#메인 꽃 배치
flower = Image.open('red_rose_1.png')
flowerInfo = toml.load('red_rose_1.toml')
change = wrapInfo['ratio'] / flowerInfo['ratio']

flower = flower.resize((int(flower.width * change), int(flower.height * change)), Image.LANCZOS)

main_cords = wrapInfo['main_cords']

for cord in main_cords:
    paste_location = (cord[0] - int(flower.width / 2), cord[1] - int(flower.height / 2))

    if flower.mode == 'RGBA':
        alpha = flower.split()[3]
        wrap.paste(flower, paste_location, mask=alpha)
    else:
        wrap.paste(flower, paste_location)

wrap.save('test.png')